using System;
using Xunit;
using MusicSearch;

namespace MusicSearch.Tests
{
    public class MusicSearchTests
    {
        [Fact]
        public void TestUnsafeArtistName()
        {
            //Arrange
            var controller = new MusicSearch.Controllers.HomeController();

            //Act
            var result = controller.CheckArtistName("OR 1=1 Delete * from Customer;");

            //Assert
            Assert.Equal(false, result);
        }

        [Fact]
        public void TestSafeArtistName()
        {
            //Arrange
            var controller = new MusicSearch.Controllers.HomeController();

            //Act
            var result = controller.CheckArtistName("nirvana");

            //Assert
            Assert.Equal(true, result);
        }
    }
}
