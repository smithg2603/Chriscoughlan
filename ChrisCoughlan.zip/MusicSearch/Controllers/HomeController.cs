﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MusicSearch.Models;
using Newtonsoft.Json;

namespace MusicSearch.Controllers
{
    public class HomeController : Controller
    {
        const string MusicBrainzExceptionMessage = "MusicBrainz Rate Limiting";
        const string MusicBrainzError = "{\"error\":";
        const string HandleError = "Error: ";
        const int RateLimitFreq = 1000; // Set to 0 to switch off
        const int RateLimitedAlbumCount = 5;
        const int RateLimitedSongCount = 20;

        /// <summary>
        /// GetMusicBrainz
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private async Task<string> GetMusicBrainz(string url)
        {
            // Chris Coughlan       -   02/03/2022
            //
            // Limitations/Simplifications to this code because of the MusicBrainz API integration.
            //
            // As this test intended to take only a few hours I have cut some corners...
            //
            // 1. Entities          -   There are no simply entity concepts relating to Artist, Song and Album.  The entity relationships are more complex, 
            //                          Artists, Release-Groups, Releases, Recordings, Works. 
            // 2. Limit/Offset      -   MusicBrainz will serve a max of 25 records from the entities even if I set limit to 100.
            // 3. Request Retrieval -   It doesn't seem possible to do one request to MusicBrainz and say "give me all the Albumns and Songs for this artist" - got to do it in multiple requests.
            // 4. Paging in UX      -   Ideally I would implement paging on the result grid and use Limit/Offset - this would also assist in Rate Limiting as time would elapse before next request.
            // 5. Rate Limiting     -   If I send more than one request per second to MusicBrainz they will (most of the time) throw back an error saying they are rate limiting.
            //                      -   Therefore I have had to delay requests by 1 second - Sleep(1000).  I'm not happy with this, it won't scale, but for the purposes of this test I'll live with it.  
            //                      -   I have limited retrieved albumns to 5 and songs to 20 so searches don't take forever.
            // 6. User Interface    -   To simplify the UX I am choosing the first Artist (rather than getting user to pick an Artist), the first Release etc.
                    
            if (RateLimitFreq > 0) System.Threading.Thread.Sleep(RateLimitFreq);

            using (var httpClient = new HttpClient())
            {
                var productInfoValue = new ProductInfoHeaderValue("MyAwesomeTagger", "1.2.0");
                httpClient.DefaultRequestHeaders.UserAgent.Add(productInfoValue);

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                var response = await httpClient.SendAsync(request);

                string content = "";

                if (response.IsSuccessStatusCode)
                {
                    content = await response.Content.ReadAsStringAsync();

                    if (content.StartsWith(MusicBrainzError)) content = HandleError + MusicBrainzExceptionMessage;
                }
                else
                {
                    content = HandleError + response.ReasonPhrase;
                }
                return content;
            }
        }

        /// <summary>
        /// GetArtist
        /// </summary>
        /// <param name="artistName"></param>
        /// <returns></returns>
        private async Task<string> GetArtist(string artistName)
        {
            var url = "http://musicbrainz.org/ws/2/artist/?query=artist:" + artistName + "&limit=1&fmt=json";
            var response = await GetMusicBrainz(url);
            string content = response.ToString();
            string artistMBID = "";

            if (!content.StartsWith(HandleError))
            {
                if (!String.IsNullOrEmpty(content))
                {
                    dynamic artist = JsonConvert.DeserializeObject(content);
                    if (artist.count > 0)
                    {
                        artistMBID = artist.artists[0].id.ToString();
                    }
                }
            }
            else artistMBID = content;

            return artistMBID;
        }

        /// <summary>
        /// GetAlbums
        /// </summary>
        /// <param name="artistMBID"></param>
        /// <returns></returns>
        private async Task<string> GetAlbums(string artistMBID)
        {
            var url = "http://musicbrainz.org/ws/2/release-group?artist=" + artistMBID + "&type=album&limit=100&fmt=json";
            var response = await GetMusicBrainz(url);
            string content = response.ToString();
            
            if (!String.IsNullOrEmpty(content))
            {
                // Newtonsoft.Json doesn't like hyphens in the Json element names so rename
                content = content.Replace("release-group-count", "releasegroupcount");
                content = content.Replace("release-groups", "releasegroups");
            }
            return content;
        }

        /// <summary>
        /// GetReleases
        /// </summary>
        /// <param name="albumMBID"></param>
        /// <returns></returns>
        private async Task<string> GetReleases(string albumMBID)
        {
            string releaseMBID = "";
            var url = "http://musicbrainz.org/ws/2/release/?release-group=" + albumMBID + "&limit=1&fmt=json";
            var response = await GetMusicBrainz(url);
            string content = response.ToString();

            if (!content.StartsWith(HandleError))
            {
                if (content != "")
                {
                    dynamic release = JsonConvert.DeserializeObject(content);
                    releaseMBID = release.releases[0].id.ToString();
                }
            }
            else releaseMBID = content;

            return releaseMBID;
        }

        /// <summary>
        /// GetSongs
        /// </summary>
        /// <param name="releaseMBID"></param>
        /// <returns></returns>
        private async Task<string> GetSongs(string releaseMBID)
        {
            var url = "http://musicbrainz.org/ws/2/release/" + releaseMBID + "?inc=recordings&limit=100&fmt=json";
            var response = await GetMusicBrainz(url);
            string content = response.ToString();

            if (!String.IsNullOrEmpty(content))
            {
                content = content.Replace("track-count", "trackcount");
            }
            return content;
        }

        /// <summary>
        /// Validate input.. a basic strategy for mitigating a security attack by validating artistName is only AlphaNumeric
        /// </summary>
        /// <param name="artistName"></param>
        /// <returns></returns>
        public bool CheckArtistName(string artistName)
        {
            return !Regex.IsMatch(artistName, @"[^a-zA-Z0-9\s]");
        }

        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// GetSongsAndAlbums
        /// </summary>
        /// <param name="artistName"></param>
        /// <returns></returns>
        public async Task<ActionResult> GetSongsAndAlbums(string artistName)
        {
            try
            {
                SongsModel songsModel = new SongsModel
                {
                    Songs = new List<SongModel>()
                };

                if (CheckArtistName(artistName))
                {
                    if (!String.IsNullOrEmpty(artistName))
                    {
                        string artistMBID = await GetArtist(artistName);

                        if (artistMBID.StartsWith(HandleError))
                        {
                            throw new InvalidOperationException(artistMBID);
                        }
                        
                        if (!String.IsNullOrEmpty(artistMBID))
                        {
                            string albumContent = await GetAlbums(artistMBID);

                            if (albumContent.StartsWith(HandleError))
                            {
                                throw new InvalidOperationException(albumContent);
                            }
                            
                            if (!String.IsNullOrEmpty(albumContent))
                            {
                                dynamic albums = JsonConvert.DeserializeObject(albumContent);

                                if (albums.releasegroupcount > 0)
                                {
                                    string albumName = "";
                                    string albumMBID = "";

                                    int albumCount = Convert.ToInt32(albums.releasegroupcount);

                                    if (albumCount != 0)
                                    {
                                        if (albumCount > RateLimitedAlbumCount) albumCount = RateLimitedAlbumCount;  // To assist with RateLimiting enforced by MusicBrainz

                                        // Loop through Albums first
                                        for (int i = 0; i < albumCount; i++)
                                        {

                                            albumName = albums.releasegroups[i].title;
                                            albumMBID = albums.releasegroups[i].id;

                                            // Get first entry from releases entity

                                            string releaseMBID = await GetReleases(albumMBID);
                                            if (releaseMBID.StartsWith(HandleError))
                                            {
                                                throw new InvalidOperationException(releaseMBID);
                                            }
                                            
                                            if (!String.IsNullOrEmpty(releaseMBID))
                                            {
                                                // Get all the songs on that Release
                                                string songsContent = await GetSongs(releaseMBID);
                                                if (songsContent.StartsWith(HandleError))
                                                {
                                                    throw new InvalidOperationException(songsContent);
                                                }

                                                if (!String.IsNullOrEmpty(songsContent))
                                                {
                                                    dynamic songs = JsonConvert.DeserializeObject(songsContent);

                                                    if (songs.media[0].trackcount > 0)
                                                    {
                                                        int songCount = Convert.ToInt32(songs.media[0].trackcount);

                                                        if (songCount != 0)
                                                        {
                                                            if (songCount > RateLimitedSongCount) songCount = RateLimitedSongCount; // To assist with RateLimiting enforced by MusicBrainz

                                                            // Loop through Songs
                                                            for (int j = 0; j < songCount; j++)
                                                            {
                                                                SongModel songModel = new SongModel();
                                                                songModel.AlbumName = albumName;
                                                                songModel.SongName = songs.media[0].tracks[j].title;
                                                                songsModel.Songs.Add(songModel);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sort by SongName
                songsModel.Songs.Sort(delegate (SongModel x, SongModel y)
                {
                    return x.SongName.CompareTo(y.SongName);
                });

                return View("Index", songsModel);

            }
            catch(Exception ex)
            {
                 ErrorViewModel error = new ErrorViewModel();
                 error.ErrorMessage = ex.Message;
                 return View("Error", error);
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { ErrorMessage = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
