﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicSearch.Models
{
    public class SongModel
    {
        public string SongName { get; set; }

        public string AlbumName { get; set; }

    }
}
